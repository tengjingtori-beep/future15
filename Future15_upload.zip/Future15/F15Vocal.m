// Future15 — stage 4 (V): Vocal Shortcuts, EXPERIMENT build
//
// The question this build answers on the real device:
//   "Can SpringBoard on iOS 15 hear a registered Japanese phrase
//    correctly, and act on it?"
// Everything the experiment learns is written to the log with a
// VOCAL_ prefix: authorisation results, on-device vs server
// recognition, every heard transcription, matches, errors.
//
// Design lines (from DESIGN.md):
//   - SpringBoard only; every other process ignores this file.
//   - Listens only while the feature is ON and the device is
//     unlocked (lock state via SBLockScreenManager + the
//     springboard lockstate darwin notification).
//   - Up to 5 phrase -> shortcut pairs from prefs.
//   - On a match: log it, speak a short confirmation (TTS), then
//     open shortcuts://run-shortcut?name=... — the same URL scheme
//     the real Vocal Shortcuts uses to fire a shortcut.
//   - All stages @try/@catch; repeated recognition errors stop the
//     listener instead of looping (the failure-brake philosophy).

#import "F15Vocal.h"
#import "F15Manager.h"
#import <UIKit/UIKit.h>
#import <Speech/Speech.h>
#import <AVFoundation/AVFoundation.h>

@interface SBLockScreenManager : NSObject
+ (instancetype)sharedInstance;
- (BOOL)isUILocked;
@end

// ---------- prefs (own snapshot; this feature lives in SpringBoard) ----------
static BOOL vEnabled = NO;          // master switch
static BOOL vVocal = NO;            // feature switch
static NSArray<NSString *> *vPhrases = nil;   // index-aligned with vShortcuts
static NSArray<NSString *> *vShortcuts = nil;

static void F15VocalLoadPrefs(void) {
    @try {
        CFStringRef app = CFSTR("com.tori.future15");
        id en = (__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("Enabled"), app);
        id vo = (__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("VocalEnabled"), app);
        vEnabled = en ? [en boolValue] : YES;
        vVocal = vo ? [vo boolValue] : NO;
        NSMutableArray *ph = [NSMutableArray array];
        NSMutableArray *sc = [NSMutableArray array];
        for (NSInteger i = 1; i <= 5; i++) {
            NSString *pk = [NSString stringWithFormat:@"VocalPhrase%ld", (long)i];
            NSString *sk = [NSString stringWithFormat:@"VocalShortcut%ld", (long)i];
            id pv = (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)pk, app);
            id sv = (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)sk, app);
            NSString *p = [pv isKindOfClass:[NSString class]] ? [pv stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] : @"";
            NSString *s = [sv isKindOfClass:[NSString class]] ? [sv stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] : @"";
            if (p.length && s.length) { [ph addObject:p]; [sc addObject:s]; }
        }
        vPhrases = [ph copy];
        vShortcuts = [sc copy];
    } @catch (__unused id e) {}
}

// ---------- state ----------
static dispatch_queue_t vQueue = nil;
static BOOL vWantListening = NO;    // prefs say "listen"
static BOOL vListening = NO;        // engine + task are running
static BOOL vSuspendedByLock = NO;
static NSInteger vGeneration = 0;   // stale-handler guard
static NSInteger vErrorStreak = 0;
static AVAudioEngine *vEngine = nil;
static SFSpeechRecognizer *vRecognizer = nil;
static SFSpeechAudioBufferRecognitionRequest *vRequest = nil;
static SFSpeechRecognitionTask *vTask = nil;
static AVSpeechSynthesizer *vSynth = nil;
static NSString *vLastHeard = nil;
static NSMutableDictionary<NSString *, NSDate *> *vLastMatchAt = nil;

static BOOL F15VocalIsSpringBoard(void) {
    return [[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@"com.apple.springboard"];
}

static BOOL F15VocalIsLocked(void) {
    @try {
        Class c = NSClassFromString(@"SBLockScreenManager");
        if (!c) return NO;
        id mgr = [c sharedInstance];
        if ([mgr respondsToSelector:@selector(isUILocked)]) return [mgr isUILocked];
    } @catch (__unused id e) {}
    return NO;
}

// Strip spaces and punctuation so "おはよう。" and "おはよう" match.
static NSString *F15VocalNormalize(NSString *s) {
    if (!s) return @"";
    NSMutableCharacterSet *drop = [NSMutableCharacterSet whitespaceAndNewlineCharacterSet];
    [drop addCharactersInString:@"、。,.!！?？・:：;；'\"“”‘’()（）「」『』"];
    return [[s componentsSeparatedByCharactersInSet:drop] componentsJoinedByString:@""].lowercaseString;
}

static void F15VocalSpeak(NSString *text) {
    dispatch_async(dispatch_get_main_queue(), ^{
        @try {
            if (!vSynth) vSynth = [[AVSpeechSynthesizer alloc] init];
            AVSpeechUtterance *u = [[AVSpeechUtterance alloc] initWithString:text];
            u.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"ja-JP"];
            u.rate = AVSpeechUtteranceDefaultSpeechRate;
            [vSynth speakUtterance:u];
        } @catch (id e) {
            F15NoteException(@"vocal.speak", e);
        }
    });
}

static void F15VocalRunShortcut(NSString *name) {
    dispatch_async(dispatch_get_main_queue(), ^{
        @try {
            NSCharacterSet *ok = [NSCharacterSet alphanumericCharacterSet];
            NSString *enc = [name stringByAddingPercentEncodingWithAllowedCharacters:ok];
            NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"shortcuts://run-shortcut?name=%@", enc ?: @""]];
            F15Log(@"VOCAL_RUN name=%@ url=%@", name, url.absoluteString);
            [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:^(BOOL success) {
                F15Log(@"VOCAL_RUN_RESULT name=%@ success=%d", name, success);
            }];
        } @catch (id e) {
            F15NoteException(@"vocal.run", e);
        }
    });
}

// ---------- engine control (always on vQueue) ----------
static void F15VocalStopLocked(NSString *reason) {
    if (!vListening && !vTask) return;
    @try {
        [vTask cancel];
        vTask = nil;
        [vRequest endAudio];
        vRequest = nil;
        if (vEngine) {
            [vEngine stop];
            [[vEngine inputNode] removeTapOnBus:0];
            vEngine = nil;
        }
        [[AVAudioSession sharedInstance] setActive:NO
                                       withOptions:AVAudioSessionSetActiveOptionNotifyOthersOnDeactivation
                                             error:nil];
    } @catch (__unused id e) {}
    vListening = NO;
    F15Log(@"VOCAL_STOPPED reason=%@", reason);
}

static void F15VocalStartTaskLocked(void); // forward

static void F15VocalScheduleRestartLocked(NSTimeInterval delay, NSString *why) {
    NSInteger gen = vGeneration;
    F15Log(@"VOCAL_RESTART in=%.1fs why=%@", delay, why);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), vQueue, ^{
        if (gen != vGeneration) return;
        if (!vWantListening || vSuspendedByLock || vListening) return;
        F15VocalStartTaskLocked();
    });
}

static void F15VocalHandleResult(SFSpeechRecognitionResult *result, NSError *error) {
    dispatch_async(vQueue, ^{
        @try {
            if (error) {
                vErrorStreak++;
                F15Log(@"VOCAL_ERROR %@ (streak=%ld)", error.localizedDescription, (long)vErrorStreak);
                vListening = NO;
                [vTask cancel]; vTask = nil;
                [vRequest endAudio]; vRequest = nil;
                if (vEngine) { [vEngine stop]; [[vEngine inputNode] removeTapOnBus:0]; vEngine = nil; }
                if (vErrorStreak >= 8) {
                    vWantListening = NO;
                    F15Log(@"VOCAL_GAVEUP too many errors in a row; toggle the feature off/on to retry");
                    F15NoteException(@"vocal.errors", error);
                    return;
                }
                if (vWantListening && !vSuspendedByLock) F15VocalScheduleRestartLocked(2.0, @"error");
                return;
            }
            if (!result) return;
            vErrorStreak = 0;
            NSString *heard = result.bestTranscription.formattedString;
            if (heard.length && ![heard isEqualToString:vLastHeard]) {
                vLastHeard = [heard copy];
                F15Log(@"VOCAL_HEARD \"%@\" final=%d", heard, result.isFinal);
            }
            NSString *normHeard = F15VocalNormalize(heard);
            if (normHeard.length) {
                for (NSUInteger i = 0; i < vPhrases.count; i++) {
                    NSString *phrase = vPhrases[i];
                    NSString *normPhrase = F15VocalNormalize(phrase);
                    if (!normPhrase.length) continue;
                    if ([normHeard rangeOfString:normPhrase].location == NSNotFound) continue;
                    // Same phrase cannot retrigger within 5 seconds.
                    NSDate *last = vLastMatchAt[phrase];
                    if (last && [[NSDate date] timeIntervalSinceDate:last] < 5.0) continue;
                    vLastMatchAt[phrase] = [NSDate date];
                    NSString *shortcut = vShortcuts[i];
                    F15Log(@"VOCAL_MATCH heard=\"%@\" phrase=%@ shortcut=%@", heard, phrase, shortcut);
                    F15VocalSpeak([NSString stringWithFormat:@"%@、聞き取れたよ", phrase]);
                    F15VocalRunShortcut(shortcut);
                    // Clear the slate so the same utterance is not
                    // matched again by the continuing task.
                    vLastHeard = nil;
                    break;
                }
            }
            if (result.isFinal) {
                vListening = NO;
                [vTask cancel]; vTask = nil;
                [vRequest endAudio]; vRequest = nil;
                if (vEngine) { [vEngine stop]; [[vEngine inputNode] removeTapOnBus:0]; vEngine = nil; }
                if (vWantListening && !vSuspendedByLock) F15VocalScheduleRestartLocked(0.6, @"final");
            }
        } @catch (id e) {
            F15NoteException(@"vocal.result", e);
        }
    });
}

static void F15VocalStartTaskLocked(void) {
    @try {
        if (vListening) return;
        if (!vRecognizer) vRecognizer = [[SFSpeechRecognizer alloc] initWithLocale:[NSLocale localeWithLocaleIdentifier:@"ja-JP"]];
        if (!vRecognizer || !vRecognizer.isAvailable) {
            F15Log(@"VOCAL_UNAVAILABLE recognizer not available right now");
            F15VocalScheduleRestartLocked(5.0, @"unavailable");
            return;
        }
        AVAudioSession *session = [AVAudioSession sharedInstance];
        [session setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
        [session setActive:YES error:nil];

        vRequest = [[SFSpeechAudioBufferRecognitionRequest alloc] init];
        vRequest.shouldReportPartialResults = YES;
        BOOL onDevice = vRecognizer.supportsOnDeviceRecognition;
        vRequest.requiresOnDeviceRecognition = onDevice;
        if (vPhrases.count) vRequest.contextualStrings = vPhrases;
        F15Log(@"VOCAL_MODE onDevice=%d pairs=%lu", onDevice, (unsigned long)vPhrases.count);

        vEngine = [[AVAudioEngine alloc] init];
        AVAudioInputNode *input = [vEngine inputNode];
        AVAudioFormat *format = [input outputFormatForBus:0];
        SFSpeechAudioBufferRecognitionRequest *req = vRequest;
        [input installTapOnBus:0 bufferSize:1024 format:format block:^(AVAudioPCMBuffer *buffer, AVAudioTime *when) {
            [req appendAudioPCMBuffer:buffer];
        }];
        [vEngine prepare];
        NSError *engErr = nil;
        if (![vEngine startAndReturnError:&engErr]) {
            F15Log(@"VOCAL_ENGINE_ERROR %@", engErr.localizedDescription);
            F15VocalScheduleRestartLocked(3.0, @"engine");
            return;
        }
        vListening = YES;
        F15Log(@"VOCAL_LISTENING");
        vTask = [vRecognizer recognitionTaskWithRequest:vRequest resultHandler:^(SFSpeechRecognitionResult *result, NSError *error) {
            F15VocalHandleResult(result, error);
        }];
    } @catch (id e) {
        F15NoteException(@"vocal.start", e);
        vListening = NO;
    }
}

static void F15VocalBeginLocked(void) {
    // Authorisation first; the log records exactly what the device
    // answers, because SpringBoard may or may not show the prompts.
    F15Log(@"VOCAL_AUTH_REQ");
    [SFSpeechRecognizer requestAuthorization:^(SFSpeechRecognizerAuthorizationStatus status) {
        F15Log(@"VOCAL_AUTH speech=%ld (3=authorized)", (long)status);
        if (status != SFSpeechRecognizerAuthorizationStatusAuthorized) {
            dispatch_async(vQueue, ^{ vWantListening = NO; });
            return;
        }
        [[AVAudioSession sharedInstance] requestRecordPermission:^(BOOL granted) {
            F15Log(@"VOCAL_AUTH mic=%d", granted);
            dispatch_async(vQueue, ^{
                if (!granted) { vWantListening = NO; return; }
                if (vWantListening && !vSuspendedByLock) F15VocalStartTaskLocked();
            });
        }];
    }];
}

static void F15VocalLockStateChanged(void) {
    dispatch_async(vQueue, ^{
        BOOL locked = F15VocalIsLocked();
        if (locked && vListening) {
            vSuspendedByLock = YES;
            F15VocalStopLocked(@"locked");
        } else if (!locked && vSuspendedByLock) {
            vSuspendedByLock = NO;
            F15Log(@"VOCAL_RESUME unlocked");
            if (vWantListening) F15VocalStartTaskLocked();
        }
    });
}

static void f15VocalLockNotify(CFNotificationCenterRef center, void *observer,
                               CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    F15VocalLockStateChanged();
}

// ---------- public entry ----------
void F15VocalApplyPrefs(void) {
    if (!F15VocalIsSpringBoard()) return;
    if (!vQueue) {
        vQueue = dispatch_queue_create("com.tori.future15.vocal", DISPATCH_QUEUE_SERIAL);
        vLastMatchAt = [NSMutableDictionary dictionary];
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
            f15VocalLockNotify, CFSTR("com.apple.springboard.lockstate"), NULL,
            CFNotificationSuspensionBehaviorDeliverImmediately);
    }
    F15VocalLoadPrefs();
    dispatch_async(vQueue, ^{
        @try {
            BOOL shouldListen = vEnabled && vVocal && vPhrases.count > 0 && ![F15Manager brakeOn];
            if (shouldListen && !vWantListening) {
                vWantListening = YES;
                vErrorStreak = 0;
                vGeneration++;
                vSuspendedByLock = F15VocalIsLocked();
                F15Log(@"VOCAL_START pairs=%lu locked=%d", (unsigned long)vPhrases.count, vSuspendedByLock);
                if (!vSuspendedByLock) F15VocalBeginLocked();
            } else if (!shouldListen && vWantListening) {
                vWantListening = NO;
                vGeneration++;
                F15VocalStopLocked(@"prefs");
                F15Log(@"VOCAL_OFF enabled=%d vocal=%d pairs=%lu",
                       vEnabled, vVocal, (unsigned long)vPhrases.count);
            } else if (shouldListen && vWantListening && !vListening && !vSuspendedByLock) {
                // Phrases were edited while listening: restart fresh.
                vGeneration++;
                F15VocalBeginLocked();
            }
        } @catch (id e) {
            F15NoteException(@"vocal.apply", e);
        }
    });
}
