// Future15 — entry point
// iPhone 7 / iOS 15 / Dopamine (rootless).
// From stage 1 the dylib is injected into every UIKit process,
// because the keyboard lives inside each app's own process.
//   - SpringBoard group: starts the manager (SpringBoard-side
//     features B/C/V will plug in there in later stages).
//   - Keyboard groups (stage 1, feature D): hook the two core
//     text-entry methods of UIKeyboardImpl. Each group is only
//     initialised when the method really exists on this iOS, so a
//     missing method can never turn into a broken %orig call.
// All decision-making (switches, brake, strength) lives in
// F15Manager; the hooks only forward the event.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "F15Manager.h"

@interface SpringBoard : UIApplication
@end

static void f15PrefsChanged(CFNotificationCenterRef center, void *observer,
                            CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[F15Manager shared] reloadPrefs];
    });
}

// ---------- SpringBoard (manager start) ----------
%group F15SpringBoardGroup
%hook SpringBoard
- (void)applicationDidFinishLaunching:(UIApplication *)application {
    %orig;
    F15Log(@"SPRINGBOARD_LAUNCHED");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[F15Manager shared] setup];
    });
}
%end
%end

// ---------- Stage 1 (D): keyboard haptics ----------
%group F15InsertTextGroup
%hook UIKeyboardImpl
- (void)insertText:(NSString *)text {
    %orig;
    @try {
        if ([text isEqualToString:@"\n"]) {
            F15KeyboardKeyPressed(F15HapticKindReturn);
        } else if (text.length == 1) {
            // Single typed characters only: pastes, dictation and
            // autocomplete inserts (multi-char) stay silent, like
            // the real iOS 16 keyboard haptics.
            F15KeyboardKeyPressed(F15HapticKindChar);
        }
    } @catch (__unused id e) {}
}
%end
%end

%group F15DeleteGroup
%hook UIKeyboardImpl
- (void)deleteBackward {
    %orig;
    @try {
        F15KeyboardKeyPressed(F15HapticKindDelete);
    } @catch (__unused id e) {}
}
%end
%end

// Diagnostic (0.2.1): proves whether real key taps travel through
// handleKeyEvent: on this iOS, and doubles as the buzz path in any
// process where the insertText: hook could not be installed.
%group F15KeyEventGroup
%hook UIKeyboardImpl
- (void)handleKeyEvent:(id)event {
    %orig;
    @try {
        F15KeyboardKeyEventSeen();
    } @catch (__unused id e) {}
}
%end
%end

%ctor {
    @autoreleasepool {
        F15LoadPrefs();
        NSString *bid = [[NSBundle mainBundle] bundleIdentifier] ?: @"?";
        BOOL isSpringBoard = [bid isEqualToString:@"com.apple.springboard"];
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
            f15PrefsChanged, (__bridge CFStringRef)@"com.tori.future15.changed", NULL,
            CFNotificationSuspensionBehaviorDeliverImmediately);

        if (isSpringBoard) {
            F15Log(@"DYLIB_LOADED version=0.2.1");
            %init(F15SpringBoardGroup);
        }

        // Keyboard hooks in every process (SpringBoard included: the
        // Spotlight and passcode keyboards live there). Each hook is
        // gated on the method really existing on this iOS build.
        Class kb = NSClassFromString(@"UIKeyboardImpl");
        BOOL insertOK = NO, deleteOK = NO, keyEventOK = NO;
        if (kb) {
            if ([kb instancesRespondToSelector:@selector(insertText:)]) {
                %init(F15InsertTextGroup);
                insertOK = YES;
            }
            if ([kb instancesRespondToSelector:@selector(deleteBackward)]) {
                %init(F15DeleteGroup);
                deleteOK = YES;
            }
            if ([kb instancesRespondToSelector:@selector(handleKeyEvent:)]) {
                %init(F15KeyEventGroup);
                keyEventOK = YES;
            }
        }
        F15SetInsertHookInstalled(insertOK);
        F15Log(@"KB_HOOKS process=%@ insertText=%d deleteBackward=%d keyEvent=%d", bid, insertOK, deleteOK, keyEventOK);
    }
}
