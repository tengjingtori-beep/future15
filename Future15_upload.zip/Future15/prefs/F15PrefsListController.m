#import "F15PrefsListController.h"
#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>

@implementation F15PrefsListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

// Test vibration: plays the currently selected strength twice over —
// once as an AudioServices system Taptic sound, once through
// UIImpactFeedbackGenerator. This runs inside the Settings app,
// independent of the tweak dylib, so it separates "this phone is not
// buzzing at all" from "the keyboard hooks are not firing".
- (void)testHaptic:(id)sender {
    (void)sender;
    NSInteger strength = 1;
    CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("HapticsStrength"),
                                                    CFSTR("com.tori.future15"));
    if (v) {
        strength = [(__bridge NSNumber *)v integerValue];
        CFRelease(v);
    }
    if (strength < 0) strength = 0;
    if (strength > 2) strength = 2;

    SystemSoundID sid = 1519;
    if (strength == 1) sid = 1520;
    if (strength == 2) sid = 1521;
    AudioServicesPlaySystemSound(sid);

    UIImpactFeedbackStyle style = UIImpactFeedbackStyleLight;
    if (strength == 1) style = UIImpactFeedbackStyleMedium;
    if (strength == 2) style = UIImpactFeedbackStyleHeavy;
    UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc] initWithStyle:style];
    [gen prepare];
    [gen impactOccurred];
}

// The tweak (SpringBoard, same mobile user) owns the log file, and the
// Settings app also runs as mobile, so it can remove it directly.
- (void)clearLog:(id)sender {
    (void)sender;
    for (NSString *path in @[@"/var/mobile/Library/Logs/Future15.log",
                             @"/var/tmp/Future15.log"]) {
        [NSFileManager.defaultManager removeItemAtPath:path error:nil];
    }
}

@end
