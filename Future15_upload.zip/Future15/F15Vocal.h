#import <Foundation/Foundation.h>

// Future15 stage 4 (V) — Vocal Shortcuts, EXPERIMENT build.
// A SpringBoard-only speech listener: while enabled (and the device
// is unlocked), it listens for up to 5 registered Japanese phrases
// with SFSpeechRecognizer; on a match it speaks a confirmation and
// runs the paired shortcut through shortcuts://run-shortcut.
// F15VocalApplyPrefs() is called whenever prefs are (re)loaded and
// starts/stops/restarts the listener to match. It is a no-op in
// every process except SpringBoard.
void F15VocalApplyPrefs(void);
