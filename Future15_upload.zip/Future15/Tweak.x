// Future15 — entry point
// iPhone 7 / iOS 15 / Dopamine (rootless) / SpringBoard only.
// All real work lives in F15Manager. This file only starts the manager
// after SpringBoard has finished launching and forwards prefs changes.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "F15Manager.h"

@interface SpringBoard : UIApplication
@end

static void f15PrefsChanged(CFNotificationCenterRef center, void *observer,
                            CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[F15Manager shared] reloadPrefs];
    });
}

%hook SpringBoard
- (void)applicationDidFinishLaunching:(UIApplication *)application {
    %orig;
    F15Log(@"SPRINGBOARD_LAUNCHED");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[F15Manager shared] setup];
    });
}
%end

%ctor {
    @autoreleasepool {
        F15LoadPrefs();
        F15Log(@"DYLIB_LOADED version=0.1.0");
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
            f15PrefsChanged, (__bridge CFStringRef)@"com.tori.future15.changed", NULL,
            CFNotificationSuspensionBehaviorDeliverImmediately);
        %init;
    }
}
