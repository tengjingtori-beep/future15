// Future15 — core
//
// Stage 0 (skeleton) proved the foundation on the real device:
// dylib loads, log writes, prefs read/re-read, failure brake.
// Stage 1 (this build) adds feature D, keyboard haptics:
//   - Tweak.x hooks UIKeyboardImpl insertText:/deleteBackward in
//     every UIKit process (the keyboard lives in the app process),
//   - the actual "should I buzz, and how hard" decision lives here,
//     behind the master switch, the feature switch, per-target
//     switches and the failure brake,
//   - playback uses UIImpactFeedbackGenerator (Light/Medium/Heavy),
//     which is what the real iOS 16 keyboard haptics feels like, and
//     the iPhone 7 has the Taptic Engine hardware for it.
// SpringBoard-side features (B/C/V) still plug into -setup later.

#import "F15Manager.h"
#import <UIKit/UIKit.h>

NSString * const kF15PrefsID = @"com.tori.future15";
NSString * const kF15PrefsChanged = @"com.tori.future15.changed";
static NSString * const kF15Version = @"0.2.0";

// ---------- prefs ----------
static BOOL prefEnabled = YES;
static BOOL prefHaptics = NO;
static NSInteger prefHapticsStrength = 1; // 0=light 1=medium 2=heavy
static BOOL prefHapticsChars = YES;
static BOOL prefHapticsDelete = YES;
static BOOL prefHapticsReturn = YES;
static BOOL prefTint = NO;
static BOOL prefStandby = NO;
static BOOL prefVocal = NO;

static id F15AppValue(NSString *key) {
    return (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)key,
                                                           (__bridge CFStringRef)kF15PrefsID);
}

void F15LoadPrefs(void) {
    @try {
        id v;
        v = F15AppValue(@"Enabled");        if (v) prefEnabled = [v boolValue];
        v = F15AppValue(@"HapticsEnabled"); if (v) prefHaptics = [v boolValue];
        v = F15AppValue(@"HapticsStrength"); if (v) prefHapticsStrength = [v integerValue];
        if (prefHapticsStrength < 0) prefHapticsStrength = 0;
        if (prefHapticsStrength > 2) prefHapticsStrength = 2;
        v = F15AppValue(@"HapticsChars");   if (v) prefHapticsChars = [v boolValue];
        v = F15AppValue(@"HapticsDelete");  if (v) prefHapticsDelete = [v boolValue];
        v = F15AppValue(@"HapticsReturn");  if (v) prefHapticsReturn = [v boolValue];
        v = F15AppValue(@"TintEnabled");    if (v) prefTint = [v boolValue];
        v = F15AppValue(@"StandbyEnabled"); if (v) prefStandby = [v boolValue];
        v = F15AppValue(@"VocalEnabled");   if (v) prefVocal = [v boolValue];
        CFPreferencesAppSynchronize((__bridge CFStringRef)kF15PrefsID);
    } @catch (__unused id e) {}
}

// ---------- log ----------
static NSFileHandle *f15LogHandle = nil;
static dispatch_queue_t f15LogQueue = nil;

static NSString *F15LogPath(void) {
    NSString *p = @"/var/mobile/Library/Logs/Future15.log";
    if ([NSFileManager.defaultManager fileExistsAtPath:p]) return p;
    NSString *dir = @"/var/mobile/Library/Logs";
    if ([NSFileManager.defaultManager createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil] &&
        [NSFileManager.defaultManager createFileAtPath:p contents:nil attributes:nil]) return p;
    return @"/var/tmp/Future15.log";
}

void F15Log(NSString *format, ...) {
    @try {
        va_list ap; va_start(ap, format);
        NSString *msg = [[NSString alloc] initWithFormat:format arguments:ap];
        va_end(ap);
        if (!f15LogQueue) f15LogQueue = dispatch_queue_create("com.tori.future15.log", DISPATCH_QUEUE_SERIAL);
        dispatch_async(f15LogQueue, ^{
            @try {
                if (!f15LogHandle) {
                    NSString *path = F15LogPath();
                    [NSFileManager.defaultManager createFileAtPath:path contents:nil attributes:nil];
                    f15LogHandle = [NSFileHandle fileHandleForWritingAtPath:path];
                }
                // The dylib now lives in many processes at once; always
                // append at the current end so lines from different
                // processes do not overwrite each other.
                [f15LogHandle seekToEndOfFile];
                NSString *line = [NSString stringWithFormat:@"[%@] %@\n",
                    [NSDateFormatter localizedStringFromDate:[NSDate date] dateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterMediumStyle], msg];
                [f15LogHandle writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
                [f15LogHandle synchronizeFile];
            } @catch (__unused id e) {}
        });
    } @catch (__unused id e) {}
}

// ---------- failure brake ----------
// After kF15BrakeThreshold exceptions anywhere in the manager, the
// brake engages: all feature activity must check +[F15Manager brakeOn]
// (and the master Enabled switch) before doing anything. The brake
// never auto-releases; a respring restarts the count. This is the
// mechanism that keeps one broken feature from looping into a
// SpringBoard crash / Safe Mode cycle.
static NSInteger gExceptionCount = 0;
static BOOL gBrakeOn = NO;
static const NSInteger kF15BrakeThreshold = 5;

void F15NoteException(NSString *where, id error) {
    gExceptionCount++;
    F15Log(@"EXCEPTION %@: %@ (count=%ld)", where, error, (long)gExceptionCount);
    if (!gBrakeOn && gExceptionCount >= kF15BrakeThreshold) {
        gBrakeOn = YES;
        F15Log(@"BRAKE_ON exceptions reached %ld: all feature activity is stopped until respring", (long)gExceptionCount);
    }
}

// ---------- stage 1 (D): keyboard haptics ----------
static UIImpactFeedbackGenerator *f15Generator = nil;
static NSInteger f15GeneratorStyle = -1;
static BOOL f15HapticFiredLogged = NO;

static BOOL F15HapticsActive(void) {
    return prefEnabled && prefHaptics && !gBrakeOn;
}

static BOOL F15TargetEnabled(F15HapticKind kind) {
    switch (kind) {
        case F15HapticKindChar:   return prefHapticsChars;
        case F15HapticKindDelete: return prefHapticsDelete;
        case F15HapticKindReturn: return prefHapticsReturn;
    }
    return NO;
}

void F15KeyboardKeyPressed(F15HapticKind kind) {
    if (!F15HapticsActive()) return;
    if (!F15TargetEnabled(kind)) return;
    @try {
        if (!f15HapticFiredLogged) {
            f15HapticFiredLogged = YES;
            F15Log(@"HAPTIC_FIRED process=%@ kind=%ld strength=%ld",
                   [[NSBundle mainBundle] bundleIdentifier] ?: @"?",
                   (long)kind, (long)prefHapticsStrength);
        }
        UIImpactFeedbackStyle style = UIImpactFeedbackStyleLight;
        if (prefHapticsStrength == 1) style = UIImpactFeedbackStyleMedium;
        if (prefHapticsStrength == 2) style = UIImpactFeedbackStyleHeavy;
        dispatch_block_t play = ^{
            @try {
                if (!f15Generator || f15GeneratorStyle != (NSInteger)style) {
                    f15Generator = [[UIImpactFeedbackGenerator alloc] initWithStyle:style];
                    f15GeneratorStyle = (NSInteger)style;
                    [f15Generator prepare];
                }
                [f15Generator impactOccurred];
                [f15Generator prepare];
            } @catch (id e) {
                F15NoteException(@"haptics.play", e);
            }
        };
        if ([NSThread isMainThread]) play();
        else dispatch_async(dispatch_get_main_queue(), play);
    } @catch (id e) {
        F15NoteException(@"haptics", e);
    }
}

// ---------- manager ----------
@interface F15Manager ()
@property (nonatomic) BOOL setupDone;
@end

@implementation F15Manager

+ (instancetype)shared {
    static F15Manager *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [[F15Manager alloc] init]; });
    return s;
}

+ (BOOL)brakeOn { return gBrakeOn; }
+ (void)logLine:(NSString *)line { F15Log(@"%@", line); }

- (void)reloadPrefs {
    F15LoadPrefs();
    F15Log(@"PREFS enabled=%d haptics=%d strength=%ld chars=%d delete=%d return=%d tint=%d standby=%d vocal=%d brake=%d",
           prefEnabled, prefHaptics, (long)prefHapticsStrength,
           prefHapticsChars, prefHapticsDelete, prefHapticsReturn,
           prefTint, prefStandby, prefVocal, gBrakeOn);
}

- (void)setup {
    if (self.setupDone) return;
    self.setupDone = YES;
    @try {
        F15Log(@"SETUP_START version=%@", kF15Version);
        [self reloadPrefs];
        F15Log(@"FEATURE_D haptics hooks are installed per-process; active=%d", F15HapticsActive());
        F15Log(@"SETUP_DONE");
    } @catch (id e) {
        F15NoteException(@"setup", e);
    }
}

@end
