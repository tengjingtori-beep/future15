// Future15 — entry point
// iPhone 7 / iOS 15 / Dopamine (rootless).
// From stage 1 the dylib is injected into every UIKit process,
// because the keyboard lives inside each app's own process.
//   - SpringBoard group: starts the manager (SpringBoard-side
//     features B/C/V will plug in there in later stages).
//   - Keyboard groups (stage 1, feature D): hook the two core
//     text-entry methods of UIKeyboardImpl. Each group is only
//     initialised when the method really exists on this iOS, so a
//     missing method can never turn into a broken %orig call.
// All decision-making (switches, brake, strength) lives in
// F15Manager; the hooks only forward the event.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "F15Manager.h"

@interface SpringBoard : UIApplication
@end

static void f15PrefsChanged(CFNotificationCenterRef center, void *observer,
                            CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[F15Manager shared] reloadPrefs];
    });
}

// ---------- SpringBoard (manager start) ----------
%group F15SpringBoardGroup
%hook SpringBoard
- (void)applicationDidFinishLaunching:(UIApplication *)application {
    %orig;
    F15Log(@"SPRINGBOARD_LAUNCHED");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[F15Manager shared] setup];
    });
}
%end
%end

// ---------- Stage 1 (D): keyboard haptics ----------
%group F15InsertTextGroup
%hook UIKeyboardImpl
- (void)insertText:(NSString *)text {
    %orig;
    @try {
        if ([text isEqualToString:@"\n"]) {
            F15KeyboardKeyPressed(F15HapticKindReturn);
        } else if (text.length == 1) {
            // Single typed characters only: pastes, dictation and
            // autocomplete inserts (multi-char) stay silent, like
            // the real iOS 16 keyboard haptics.
            F15KeyboardKeyPressed(F15HapticKindChar);
        }
    } @catch (__unused id e) {}
}
%end
%end

%group F15DeleteGroup
%hook UIKeyboardImpl
- (void)deleteBackward {
    %orig;
    @try {
        F15KeyboardKeyPressed(F15HapticKindDelete);
    } @catch (__unused id e) {}
}
%end
%end

// Diagnostic (0.2.1): proves whether real key taps travel through
// handleKeyEvent: on this iOS, and doubles as the buzz path in any
// process where the insertText: hook could not be installed.
// 0.2.2 adds a one-time detail line (event class / characters) so
// the log shows what actually flows through here.
static BOOL f15KeyEventDetailLogged = NO;
%group F15KeyEventGroup
%hook UIKeyboardImpl
- (void)handleKeyEvent:(id)event {
    %orig;
    @try {
        if (!f15KeyEventDetailLogged) {
            f15KeyEventDetailLogged = YES;
            NSString *chars = nil;
            if ([event respondsToSelector:@selector(characters)]) {
                chars = [event valueForKey:@"characters"];
            }
            F15Log(@"KEYEVENT_DETAIL process=%@ class=%@ characters=%@",
                   [[NSBundle mainBundle] bundleIdentifier] ?: @"?",
                   event ? NSStringFromClass([event class]) : @"nil",
                   chars ?: @"-");
        }
        F15KeyboardKeyEventSeen();
    } @catch (__unused id e) {}
}
%end
%end

// ---------- 0.2.2: candidate key paths ----------
// The 0.2.x device tests proved playback works but the captured
// path never fired for real typing, and the surviving log line
// showed insertText: missing on UIKeyboardImpl in at least one
// process. So 0.2.2 hooks every plausible road a key tap can take,
// each gated on the method really existing, each announcing its
// first fire with PATH_FIRED. The shared 40 ms debounce in the
// manager keeps overlapping paths from double-buzzing one tap.

%group F15HandleKeyStringGroup
%hook UIKeyboardImpl
- (void)handleKeyWithString:(id)string forKeyboard:(id)keyboard {
    %orig;
    @try {
        F15PathFired(@"UIKeyboardImpl.handleKeyWithString");
        F15KeyboardKeyPressed(F15HapticKindChar);
    } @catch (__unused id e) {}
}
%end
%end

%group F15TextViewGroup
%hook UITextView
- (void)insertText:(NSString *)text {
    %orig;
    @try {
        F15PathFired(@"UITextView.insertText");
        if ([text isEqualToString:@"\n"]) {
            F15KeyboardKeyPressed(F15HapticKindReturn);
        } else if (text.length == 1) {
            F15KeyboardKeyPressed(F15HapticKindChar);
        }
    } @catch (__unused id e) {}
}
- (void)deleteBackward {
    %orig;
    @try {
        F15PathFired(@"UITextView.deleteBackward");
        F15KeyboardKeyPressed(F15HapticKindDelete);
    } @catch (__unused id e) {}
}
%end
%end

%group F15TextFieldGroup
%hook UITextField
- (void)insertText:(NSString *)text {
    %orig;
    @try {
        F15PathFired(@"UITextField.insertText");
        if ([text isEqualToString:@"\n"]) {
            F15KeyboardKeyPressed(F15HapticKindReturn);
        } else if (text.length == 1) {
            F15KeyboardKeyPressed(F15HapticKindChar);
        }
    } @catch (__unused id e) {}
}
- (void)deleteBackward {
    %orig;
    @try {
        F15PathFired(@"UITextField.deleteBackward");
        F15KeyboardKeyPressed(F15HapticKindDelete);
    } @catch (__unused id e) {}
}
%end
%end

// One line per process listing every UIKeyboardImpl method whose
// name smells like key handling. This turns "which method carries
// real taps on iOS 15" from a guess into evidence.
static void F15DumpKeyboardMethods(NSString *bid) {
    @try {
        Class kb = NSClassFromString(@"UIKeyboardImpl");
        if (!kb) return;
        unsigned int count = 0;
        Method *methods = class_copyMethodList(kb, &count);
        NSMutableArray<NSString *> *names = [NSMutableArray array];
        NSArray<NSString *> *keys = @[@"insert", @"delete", @"handle", @"key", @"input"];
        for (unsigned int i = 0; i < count; i++) {
            NSString *name = NSStringFromSelector(method_getName(methods[i]));
            NSString *low = name.lowercaseString;
            for (NSString *k in keys) {
                if ([low containsString:k]) { [names addObject:name]; break; }
            }
        }
        if (methods) free(methods);
        [names sortUsingSelector:@selector(compare:)];
        F15Log(@"KB_METHODS process=%@ count=%lu methods=%@", bid,
               (unsigned long)names.count, [names componentsJoinedByString:@","]);
    } @catch (__unused id e) {}
}

%ctor {
    @autoreleasepool {
        F15LoadPrefs();
        NSString *bid = [[NSBundle mainBundle] bundleIdentifier] ?: @"?";
        BOOL isSpringBoard = [bid isEqualToString:@"com.apple.springboard"];
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
            f15PrefsChanged, (__bridge CFStringRef)@"com.tori.future15.changed", NULL,
            CFNotificationSuspensionBehaviorDeliverImmediately);

        if (isSpringBoard) {
            F15Log(@"DYLIB_LOADED version=0.2.2");
            %init(F15SpringBoardGroup);
        }

        // Keyboard hooks in every process (SpringBoard included: the
        // Spotlight and passcode keyboards live there). Each hook is
        // gated on the method really existing on this iOS build.
        Class kb = NSClassFromString(@"UIKeyboardImpl");
        BOOL insertOK = NO, deleteOK = NO, keyEventOK = NO, hkwsOK = NO;
        if (kb) {
            if ([kb instancesRespondToSelector:@selector(insertText:)]) {
                %init(F15InsertTextGroup);
                insertOK = YES;
            }
            if ([kb instancesRespondToSelector:@selector(deleteBackward)]) {
                %init(F15DeleteGroup);
                deleteOK = YES;
            }
            if ([kb instancesRespondToSelector:@selector(handleKeyEvent:)]) {
                %init(F15KeyEventGroup);
                keyEventOK = YES;
            }
            if ([kb instancesRespondToSelector:@selector(handleKeyWithString:forKeyboard:)]) {
                %init(F15HandleKeyStringGroup);
                hkwsOK = YES;
            }
        }
        // Text-side candidates: the words land in the text view /
        // text field (the keyboard's input delegate), so hook the
        // UIKeyInput methods there too.
        BOOL tvInsertOK = NO, tfInsertOK = NO;
        Class tv = NSClassFromString(@"UITextView");
        if (tv && [tv instancesRespondToSelector:@selector(insertText:)]) {
            %init(F15TextViewGroup);
            tvInsertOK = YES;
        }
        Class tf = NSClassFromString(@"UITextField");
        if (tf && [tf instancesRespondToSelector:@selector(insertText:)]) {
            %init(F15TextFieldGroup);
            tfInsertOK = YES;
        }
        F15SetInsertHookInstalled(insertOK);
        F15Log(@"KB_HOOKS process=%@ insertText=%d deleteBackward=%d keyEvent=%d hkws=%d tvInsert=%d tfInsert=%d",
               bid, insertOK, deleteOK, keyEventOK, hkwsOK, tvInsertOK, tfInsertOK);
        F15DumpKeyboardMethods(bid);
    }
}
