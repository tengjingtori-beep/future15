#import <Preferences/PSListController.h>

@interface F15PrefsListController : PSListController
@end
