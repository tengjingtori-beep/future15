// Future15 — core
//
// Stage 0 (skeleton) proved the foundation on the real device:
// dylib loads, log writes, prefs read/re-read, failure brake.
// Stage 1 adds feature D, keyboard haptics:
//   - Tweak.x hooks UIKeyboardImpl insertText:/deleteBackward in
//     every UIKit process (the keyboard lives in the app process),
//   - the actual "should I buzz, and how hard" decision lives here,
//     behind the master switch, the feature switch, per-target
//     switches and the failure brake.
// Version 0.2.0 used UIImpactFeedbackGenerator and produced NO
// vibration on the real device even with every switch on, so 0.2.1
// switches playback to the AudioServices system Taptic sounds
// (1519/1520/1521 by strength): stateless, no main-thread or
// app-state requirements, the classic tweak approach. 0.2.1 also
// adds a Settings test-vibration button, a handleKeyEvent: sighting
// hook, and HAPTIC_BLOCKED logging so the next device report can
// separate "hooks never fire" from "playback is silent".
// SpringBoard-side features (B/C/V) still plug into -setup later.

#import "F15Manager.h"
#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>

NSString * const kF15PrefsID = @"com.tori.future15";
NSString * const kF15PrefsChanged = @"com.tori.future15.changed";
static NSString * const kF15Version = @"0.2.2";

// ---------- prefs ----------
static BOOL prefEnabled = YES;
static BOOL prefHaptics = NO;
static NSInteger prefHapticsStrength = 1; // 0=light 1=medium 2=heavy
static BOOL prefHapticsChars = YES;
static BOOL prefHapticsDelete = YES;
static BOOL prefHapticsReturn = YES;
static BOOL prefTint = NO;
static BOOL prefStandby = NO;
static BOOL prefVocal = NO;

static id F15AppValue(NSString *key) {
    return (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)key,
                                                           (__bridge CFStringRef)kF15PrefsID);
}

void F15LoadPrefs(void) {
    @try {
        id v;
        v = F15AppValue(@"Enabled");        if (v) prefEnabled = [v boolValue];
        v = F15AppValue(@"HapticsEnabled"); if (v) prefHaptics = [v boolValue];
        v = F15AppValue(@"HapticsStrength"); if (v) prefHapticsStrength = [v integerValue];
        if (prefHapticsStrength < 0) prefHapticsStrength = 0;
        if (prefHapticsStrength > 2) prefHapticsStrength = 2;
        v = F15AppValue(@"HapticsChars");   if (v) prefHapticsChars = [v boolValue];
        v = F15AppValue(@"HapticsDelete");  if (v) prefHapticsDelete = [v boolValue];
        v = F15AppValue(@"HapticsReturn");  if (v) prefHapticsReturn = [v boolValue];
        v = F15AppValue(@"TintEnabled");    if (v) prefTint = [v boolValue];
        v = F15AppValue(@"StandbyEnabled"); if (v) prefStandby = [v boolValue];
        v = F15AppValue(@"VocalEnabled");   if (v) prefVocal = [v boolValue];
        CFPreferencesAppSynchronize((__bridge CFStringRef)kF15PrefsID);
    } @catch (__unused id e) {}
}

// ---------- log ----------
static NSFileHandle *f15LogHandle = nil;
static dispatch_queue_t f15LogQueue = nil;

static NSString *F15LogPath(void) {
    NSString *p = @"/var/mobile/Library/Logs/Future15.log";
    if ([NSFileManager.defaultManager fileExistsAtPath:p]) return p;
    NSString *dir = @"/var/mobile/Library/Logs";
    if ([NSFileManager.defaultManager createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil] &&
        [NSFileManager.defaultManager createFileAtPath:p contents:nil attributes:nil]) return p;
    return @"/var/tmp/Future15.log";
}

void F15Log(NSString *format, ...) {
    @try {
        va_list ap; va_start(ap, format);
        NSString *msg = [[NSString alloc] initWithFormat:format arguments:ap];
        va_end(ap);
        if (!f15LogQueue) f15LogQueue = dispatch_queue_create("com.tori.future15.log", DISPATCH_QUEUE_SERIAL);
        dispatch_async(f15LogQueue, ^{
            @try {
                if (!f15LogHandle) {
                    // 0.2.2 fix: NEVER create-with-nil-contents here.
                    // createFileAtPath truncates an existing file, and
                    // because every injected process runs this once,
                    // each new process was erasing the lines earlier
                    // processes had written (the "2-line log" bug).
                    // F15LogPath already creates the file if missing.
                    NSString *path = F15LogPath();
                    f15LogHandle = [NSFileHandle fileHandleForWritingAtPath:path];
                    [f15LogHandle seekToEndOfFile];
                }
                // The dylib now lives in many processes at once; always
                // append at the current end so lines from different
                // processes do not overwrite each other.
                [f15LogHandle seekToEndOfFile];
                NSString *line = [NSString stringWithFormat:@"[%@] %@\n",
                    [NSDateFormatter localizedStringFromDate:[NSDate date] dateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterMediumStyle], msg];
                [f15LogHandle writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
                [f15LogHandle synchronizeFile];
            } @catch (__unused id e) {}
        });
    } @catch (__unused id e) {}
}

// ---------- failure brake ----------
// After kF15BrakeThreshold exceptions anywhere in the manager, the
// brake engages: all feature activity must check +[F15Manager brakeOn]
// (and the master Enabled switch) before doing anything. The brake
// never auto-releases; a respring restarts the count. This is the
// mechanism that keeps one broken feature from looping into a
// SpringBoard crash / Safe Mode cycle.
static NSInteger gExceptionCount = 0;
static BOOL gBrakeOn = NO;
static const NSInteger kF15BrakeThreshold = 5;

void F15NoteException(NSString *where, id error) {
    gExceptionCount++;
    F15Log(@"EXCEPTION %@: %@ (count=%ld)", where, error, (long)gExceptionCount);
    if (!gBrakeOn && gExceptionCount >= kF15BrakeThreshold) {
        gBrakeOn = YES;
        F15Log(@"BRAKE_ON exceptions reached %ld: all feature activity is stopped until respring", (long)gExceptionCount);
    }
}

// ---------- stage 1 (D): keyboard haptics ----------
static BOOL f15HapticFiredLogged = NO;
static BOOL f15BlockedLogged = NO;
static CFAbsoluteTime f15LastBuzzTime = 0;

static BOOL F15HapticsActive(void) {
    return prefEnabled && prefHaptics && !gBrakeOn;
}

static BOOL F15TargetEnabled(F15HapticKind kind) {
    switch (kind) {
        case F15HapticKindChar:   return prefHapticsChars;
        case F15HapticKindDelete: return prefHapticsDelete;
        case F15HapticKindReturn: return prefHapticsReturn;
    }
    return NO;
}

void F15KeyboardKeyPressed(F15HapticKind kind) {
    if (!F15HapticsActive() || !F15TargetEnabled(kind)) {
        // One line per process is enough to prove "the hook fired but
        // the switches kept it silent" (and which switch did it).
        if (!f15BlockedLogged) {
            f15BlockedLogged = YES;
            F15Log(@"HAPTIC_BLOCKED process=%@ kind=%ld enabled=%d haptics=%d brake=%d",
                   [[NSBundle mainBundle] bundleIdentifier] ?: @"?",
                   (long)kind, prefEnabled, prefHaptics, gBrakeOn);
        }
        return;
    }
    @try {
        // Several hook paths can report the same physical tap; only
        // the first one inside the debounce window actually buzzes.
        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        if (now - f15LastBuzzTime < 0.04) return;
        f15LastBuzzTime = now;
        if (!f15HapticFiredLogged) {
            f15HapticFiredLogged = YES;
            F15Log(@"HAPTIC_FIRED process=%@ kind=%ld strength=%ld method=audio",
                   [[NSBundle mainBundle] bundleIdentifier] ?: @"?",
                   (long)kind, (long)prefHapticsStrength);
        }
        // System Taptic sounds: 1519 = light tap, 1520 = medium,
        // 1521 = strong. Played through AudioServices, so no
        // generator lifecycle, thread or app-state conditions.
        SystemSoundID sid = 1519;
        if (prefHapticsStrength == 1) sid = 1520;
        if (prefHapticsStrength == 2) sid = 1521;
        AudioServicesPlaySystemSound(sid);
    } @catch (id e) {
        F15NoteException(@"haptics", e);
    }
}

// ---------- stage 1.1 diagnostics: handleKeyEvent: sightings ----------
static BOOL f15InsertHookInstalled = NO;
static BOOL f15KeyEventSeenLogged = NO;

void F15SetInsertHookInstalled(BOOL installed) {
    f15InsertHookInstalled = installed;
}

void F15KeyboardKeyEventSeen(void) {
    if (!f15KeyEventSeenLogged) {
        f15KeyEventSeenLogged = YES;
        F15Log(@"KEYEVENT_SEEN process=%@ insertHook=%d",
               [[NSBundle mainBundle] bundleIdentifier] ?: @"?",
               f15InsertHookInstalled);
    }
    // Only use key events as the buzz path when the text-insertion
    // hook could not be installed in this process; when both exist,
    // buzzing from both would double every tap.
    if (!f15InsertHookInstalled) {
        F15KeyboardKeyPressed(F15HapticKindChar);
    }
}

// ---------- 0.2.2 path discovery ----------
static NSMutableSet<NSString *> *f15FiredPaths = nil;

void F15PathFired(NSString *path) {
    @try {
        if (!f15FiredPaths) f15FiredPaths = [NSMutableSet set];
        if ([f15FiredPaths containsObject:path]) return;
        [f15FiredPaths addObject:path];
        F15Log(@"PATH_FIRED process=%@ path=%@",
               [[NSBundle mainBundle] bundleIdentifier] ?: @"?", path);
    } @catch (__unused id e) {}
}

// ---------- manager ----------
@interface F15Manager ()
@property (nonatomic) BOOL setupDone;
@end

@implementation F15Manager

+ (instancetype)shared {
    static F15Manager *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [[F15Manager alloc] init]; });
    return s;
}

+ (BOOL)brakeOn { return gBrakeOn; }
+ (void)logLine:(NSString *)line { F15Log(@"%@", line); }

- (void)reloadPrefs {
    F15LoadPrefs();
    F15Log(@"PREFS process=%@ enabled=%d haptics=%d strength=%ld chars=%d delete=%d return=%d tint=%d standby=%d vocal=%d brake=%d",
           [[NSBundle mainBundle] bundleIdentifier] ?: @"?",
           prefEnabled, prefHaptics, (long)prefHapticsStrength,
           prefHapticsChars, prefHapticsDelete, prefHapticsReturn,
           prefTint, prefStandby, prefVocal, gBrakeOn);
    // 0.2.2: the vocal listener no longer lives in SpringBoard.
    // The 0.3.x experiment ended in Safe Mode on the real device,
    // so the listener was removed from the dylib entirely; feature
    // V returns later as a separate app (outside SpringBoard).
}

- (void)setup {
    if (self.setupDone) return;
    self.setupDone = YES;
    @try {
        F15Log(@"SETUP_START version=%@", kF15Version);
        [self reloadPrefs];
        F15Log(@"FEATURE_V removed from SpringBoard in 0.2.2 (0.3.x caused Safe Mode); app-based redesign is next");
        F15Log(@"FEATURE_D haptics hooks are installed per-process; active=%d", F15HapticsActive());
        F15Log(@"SETUP_DONE");
    } @catch (id e) {
        F15NoteException(@"setup", e);
    }
}

@end
