// Future15 — core (skeleton stage 0)
//
// What this stage does
//   Nothing user-visible yet. It proves the foundation on the real
//   device before any feature is added:
//     1. the dylib is loaded by ElleKit into SpringBoard,
//     2. the diagnostic log can be written,
//     3. the prefs (master switch + one switch per future feature)
//        can be read and re-read when they change,
//     4. the failure brake works: after 5 exceptions the manager
//        stops all activity and only logs that it stopped.
//   Every later feature plugs into this same manager, so a failure
//   in one feature can be cut off by the brake and by its own
//   switch without touching the others.

#import "F15Manager.h"
#import <UIKit/UIKit.h>

NSString * const kF15PrefsID = @"com.tori.future15";
NSString * const kF15PrefsChanged = @"com.tori.future15.changed";
static NSString * const kF15Version = @"0.1.0";

// ---------- prefs ----------
static BOOL prefEnabled = YES;
static BOOL prefHaptics = NO;
static BOOL prefTint = NO;
static BOOL prefStandby = NO;
static BOOL prefVocal = NO;

static id F15AppValue(NSString *key) {
    return (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)key,
                                                           (__bridge CFStringRef)kF15PrefsID);
}

void F15LoadPrefs(void) {
    @try {
        id v;
        v = F15AppValue(@"Enabled");        if (v) prefEnabled = [v boolValue];
        v = F15AppValue(@"HapticsEnabled"); if (v) prefHaptics = [v boolValue];
        v = F15AppValue(@"TintEnabled");    if (v) prefTint = [v boolValue];
        v = F15AppValue(@"StandbyEnabled"); if (v) prefStandby = [v boolValue];
        v = F15AppValue(@"VocalEnabled");   if (v) prefVocal = [v boolValue];
        CFPreferencesAppSynchronize((__bridge CFStringRef)kF15PrefsID);
    } @catch (__unused id e) {}
}

// ---------- log ----------
static NSFileHandle *f15LogHandle = nil;
static dispatch_queue_t f15LogQueue = nil;

static NSString *F15LogPath(void) {
    NSString *p = @"/var/mobile/Library/Logs/Future15.log";
    if ([NSFileManager.defaultManager fileExistsAtPath:p]) return p;
    NSString *dir = @"/var/mobile/Library/Logs";
    if ([NSFileManager.defaultManager createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil] &&
        [NSFileManager.defaultManager createFileAtPath:p contents:nil attributes:nil]) return p;
    return @"/var/tmp/Future15.log";
}

void F15Log(NSString *format, ...) {
    @try {
        va_list ap; va_start(ap, format);
        NSString *msg = [[NSString alloc] initWithFormat:format arguments:ap];
        va_end(ap);
        if (!f15LogQueue) f15LogQueue = dispatch_queue_create("com.tori.future15.log", DISPATCH_QUEUE_SERIAL);
        dispatch_async(f15LogQueue, ^{
            @try {
                if (!f15LogHandle) {
                    NSString *path = F15LogPath();
                    [NSFileManager.defaultManager createFileAtPath:path contents:nil attributes:nil];
                    f15LogHandle = [NSFileHandle fileHandleForWritingAtPath:path];
                    [f15LogHandle seekToEndOfFile];
                }
                NSString *line = [NSString stringWithFormat:@"[%@] %@\n",
                    [NSDateFormatter localizedStringFromDate:[NSDate date] dateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterMediumStyle], msg];
                [f15LogHandle writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
                [f15LogHandle synchronizeFile];
            } @catch (__unused id e) {}
        });
    } @catch (__unused id e) {}
}

// ---------- failure brake ----------
// After kF15BrakeThreshold exceptions anywhere in the manager, the
// brake engages: all feature activity must check +[F15Manager brakeOn]
// (and the master Enabled switch) before doing anything. The brake
// never auto-releases; a respring restarts the count. This is the
// mechanism that keeps one broken feature from looping into a
// SpringBoard crash / Safe Mode cycle.
static NSInteger gExceptionCount = 0;
static BOOL gBrakeOn = NO;
static const NSInteger kF15BrakeThreshold = 5;

void F15NoteException(NSString *where, id error) {
    gExceptionCount++;
    F15Log(@"EXCEPTION %@: %@ (count=%ld)", where, error, (long)gExceptionCount);
    if (!gBrakeOn && gExceptionCount >= kF15BrakeThreshold) {
        gBrakeOn = YES;
        F15Log(@"BRAKE_ON exceptions reached %ld: all feature activity is stopped until respring", (long)gExceptionCount);
    }
}

// ---------- manager ----------
@interface F15Manager ()
@property (nonatomic) BOOL setupDone;
@end

@implementation F15Manager

+ (instancetype)shared {
    static F15Manager *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [[F15Manager alloc] init]; });
    return s;
}

+ (BOOL)brakeOn { return gBrakeOn; }
+ (void)logLine:(NSString *)line { F15Log(@"%@", line); }

- (void)reloadPrefs {
    F15LoadPrefs();
    F15Log(@"PREFS enabled=%d haptics=%d tint=%d standby=%d vocal=%d brake=%d",
           prefEnabled, prefHaptics, prefTint, prefStandby, prefVocal, gBrakeOn);
}

- (void)setup {
    if (self.setupDone) return;
    self.setupDone = YES;
    @try {
        F15Log(@"SETUP_START version=%@", kF15Version);
        [self reloadPrefs];
        // Skeleton stage: no feature hooks are installed here.
        // Each feature arrives in its own stage and logs its own
        // FEATURE_SETUP line when it really starts.
        F15Log(@"SKELETON_READY features are placeholders in Settings; nothing is active yet");
        F15Log(@"SETUP_DONE");
    } @catch (id e) {
        F15NoteException(@"setup", e);
    }
}

@end
