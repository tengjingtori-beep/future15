#import <Foundation/Foundation.h>

// Future15 manager:
// owns the diagnostic log, the prefs snapshot and the failure brake.
// Features plug in one stage at a time; every feature path must pass
// through the brake and write to the log so a failure can be traced.
@interface F15Manager : NSObject
+ (instancetype)shared;
- (void)setup;
- (void)reloadPrefs;
+ (BOOL)brakeOn;
+ (void)logLine:(NSString *)line;
@end

// Shared prefs / logging / brake helpers used by Tweak.x too.
void F15LoadPrefs(void);
void F15Log(NSString *format, ...);
void F15NoteException(NSString *where, id error);

// ---- Stage 1 (D): keyboard haptics ----
// Kinds of key presses the haptic engine distinguishes, matching the
// per-target switches in Settings (chars / delete / return).
typedef NS_ENUM(NSInteger, F15HapticKind) {
    F15HapticKindChar = 0,
    F15HapticKindDelete = 1,
    F15HapticKindReturn = 2,
};
// Called from the keyboard hooks in any process. Internally checks the
// master switch, the haptics switch, the per-target switches and the
// failure brake before playing anything, and never throws.
void F15KeyboardKeyPressed(F15HapticKind kind);

// ---- Stage 1.1 diagnostics ----
// Tweak.x reports whether the insertText: hook could be installed in
// this process, and forwards handleKeyEvent: sightings. If the
// insertText: hook is missing, key events become the buzz path;
// if it exists, key events are only logged (first sighting per
// process) so the log can prove which path real key taps take.
void F15SetInsertHookInstalled(BOOL installed);
void F15KeyboardKeyEventSeen(void);

// ---- 0.2.2 path discovery ----
// Every candidate key path calls this the first time it fires in a
// process, so the log can prove which road real key taps take.
void F15PathFired(NSString *path);
