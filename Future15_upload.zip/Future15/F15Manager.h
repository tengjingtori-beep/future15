#import <Foundation/Foundation.h>

// Future15 manager:
// owns the diagnostic log, the prefs snapshot and the failure brake.
// Features plug in one stage at a time; every feature path must pass
// through the brake and write to the log so a failure can be traced.
@interface F15Manager : NSObject
+ (instancetype)shared;
- (void)setup;
- (void)reloadPrefs;
+ (BOOL)brakeOn;
+ (void)logLine:(NSString *)line;
@end

// Shared prefs / logging / brake helpers used by Tweak.x too.
void F15LoadPrefs(void);
void F15Log(NSString *format, ...);
void F15NoteException(NSString *where, id error);

// ---- Stage 1 (D): keyboard haptics ----
// Kinds of key presses the haptic engine distinguishes, matching the
// per-target switches in Settings (chars / delete / return).
typedef NS_ENUM(NSInteger, F15HapticKind) {
    F15HapticKindChar = 0,
    F15HapticKindDelete = 1,
    F15HapticKindReturn = 2,
};
// Called from the keyboard hooks in any process. Internally checks the
// master switch, the haptics switch, the per-target switches and the
// failure brake before playing anything, and never throws.
void F15KeyboardKeyPressed(F15HapticKind kind);
