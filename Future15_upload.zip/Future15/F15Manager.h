#import <Foundation/Foundation.h>

// Future15 manager (skeleton stage 0):
// owns the diagnostic log, the prefs snapshot and the failure brake.
// No feature hooks exist yet; features are added one stage at a time
// and each one must pass through the brake and the log.
@interface F15Manager : NSObject
+ (instancetype)shared;
- (void)setup;
- (void)reloadPrefs;
+ (BOOL)brakeOn;
+ (void)logLine:(NSString *)line;
@end

// Shared prefs / logging / brake helpers used by Tweak.x too.
void F15LoadPrefs(void);
void F15Log(NSString *format, ...);
void F15NoteException(NSString *where, id error);
