#import "F15PrefsListController.h"
#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>
#import <Preferences/PSSpecifier.h>

@implementation F15PrefsListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
        [self f15RefreshStrengthLabels];
    }
    return _specifiers;
}

// ---------- strength picker (buttons, 0.2.2) ----------
// The list-picker control (PSLinkListCell + PSListItemsController)
// crashes the Settings app on this iPhone 7, so strength is chosen
// with three plain buttons — the control VoiceChat15 proved on the
// same device. The current choice gets a "(今これ)" marker, and
// tapping a button also plays a test buzz at that strength.
- (NSInteger)f15CurrentStrength {
    NSInteger strength = 1;
    CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("HapticsStrength"),
                                                    CFSTR("com.tori.future15"));
    if (v) {
        strength = [(__bridge NSNumber *)v integerValue];
        CFRelease(v);
    }
    if (strength < 0) strength = 0;
    if (strength > 2) strength = 2;
    return strength;
}

- (void)f15RefreshStrengthLabels {
    @try {
        NSInteger cur = [self f15CurrentStrength];
        NSArray<NSString *> *base = @[@"弱い", @"ちょうどいい", @"強い"];
        for (PSSpecifier *spec in _specifiers) {
            NSString *sid = [spec propertyForKey:@"id"];
            NSInteger idx = -1;
            if ([sid isEqualToString:@"strength0"]) idx = 0;
            else if ([sid isEqualToString:@"strength1"]) idx = 1;
            else if ([sid isEqualToString:@"strength2"]) idx = 2;
            if (idx < 0) continue;
            NSString *label = base[idx];
            if (idx == cur) label = [label stringByAppendingString:@"（今これ）"];
            spec.name = label;
        }
    } @catch (__unused id e) {}
}

- (void)f15SetStrength:(NSInteger)strength {
    CFPreferencesSetAppValue(CFSTR("HapticsStrength"),
                             (__bridge CFPropertyListRef)@(strength),
                             CFSTR("com.tori.future15"));
    CFPreferencesAppSynchronize(CFSTR("com.tori.future15"));
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                         CFSTR("com.tori.future15.changed"),
                                         NULL, NULL, true);
    SystemSoundID sid = 1519;
    if (strength == 1) sid = 1520;
    if (strength == 2) sid = 1521;
    AudioServicesPlaySystemSound(sid);
    [self reloadSpecifiers];
}

- (void)setStrength0:(id)sender { (void)sender; [self f15SetStrength:0]; }
- (void)setStrength1:(id)sender { (void)sender; [self f15SetStrength:1]; }
- (void)setStrength2:(id)sender { (void)sender; [self f15SetStrength:2]; }

// Test vibration: plays the currently selected strength twice over —
// once as an AudioServices system Taptic sound, once through
// UIImpactFeedbackGenerator. This runs inside the Settings app,
// independent of the tweak dylib, so it separates "this phone is not
// buzzing at all" from "the keyboard hooks are not firing".
- (void)testHaptic:(id)sender {
    (void)sender;
    NSInteger strength = 1;
    CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("HapticsStrength"),
                                                    CFSTR("com.tori.future15"));
    if (v) {
        strength = [(__bridge NSNumber *)v integerValue];
        CFRelease(v);
    }
    if (strength < 0) strength = 0;
    if (strength > 2) strength = 2;

    SystemSoundID sid = 1519;
    if (strength == 1) sid = 1520;
    if (strength == 2) sid = 1521;
    AudioServicesPlaySystemSound(sid);

    UIImpactFeedbackStyle style = UIImpactFeedbackStyleLight;
    if (strength == 1) style = UIImpactFeedbackStyleMedium;
    if (strength == 2) style = UIImpactFeedbackStyleHeavy;
    UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc] initWithStyle:style];
    [gen prepare];
    [gen impactOccurred];
}

// The tweak (SpringBoard, same mobile user) owns the log file, and the
// Settings app also runs as mobile, so it can remove it directly.
- (void)clearLog:(id)sender {
    (void)sender;
    for (NSString *path in @[@"/var/mobile/Library/Logs/Future15.log",
                             @"/var/tmp/Future15.log"]) {
        [NSFileManager.defaultManager removeItemAtPath:path error:nil];
    }
}

@end
